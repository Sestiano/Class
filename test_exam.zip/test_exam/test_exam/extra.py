"""
Exercise: Word Frequency Analysis from Multiple Text Files

Write a Python program that reads all text files in `data/`, combines the contents of these files, and performs a frequency analysis on the words. The program should output the most common words and their frequencies ordered from the highest to the lowest

"""